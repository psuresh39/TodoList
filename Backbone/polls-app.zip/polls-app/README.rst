===========================
Polls Application V1.0
===========================

This is an interactive polls application.

User Stories
======================
    1. User can visit polls/ link and get a random polls question
    2. User can choose to participate in it or click "Show Another Poll" which loads a new poll
    3. User can select an answer for a poll and submit it
    4. User cna view results i.e vote counts for each answer to the poll
    5. The results page is real-time and loads up latest results (without page refresh)
        How to test this?:
            -Two different browser windows can be used to test this out.
            -Answer any poll and go to results page for that poll
            -In another browser answer same question. Data should update on both browsers

    6. After answering the user can chose to answer another question by clicking on "Show Another Poll". User is
       redirected to /polls url and a new question loads up.

Technologies Used
======================
    1. Front-end: backbone.js, jQuery
    2. Back-end: Django, Django REST Framework, sqlite3 database

How to run:


Getting Set Up
======================

    cd polls-app
    virtualenv venv
    source venv/bin/activate
    pip install -r requirements.txt

There is a SQLite database bundled with the project (username:
admin, password: pollsapp), so you should
just be able to start running.  First, make sure the tests pass::

    ./manage.py test polls

You should get output that looks like::

    Creating test database for alias 'default'...
    ............
    ----------------------------------------------------------------------
    Ran 10 tests in 0.398s

    OK
    Destroying test database for alias 'default'...

Now, run the server::

    ./manage.py runserver

In your browser, go to http://localhost:8000/polls/


I've also hosted the project on a public Linode server:

 http://96.126.103.227/polls


Todo/Improvements in no particular order
======================


 1. Shift to a PostgreSQL or MySQL database
 2. Improve UI
 3. Create background task-queue to generate fresh questions once a day/hour etc. so fresh polls appear each day/hour
 4. Learn user preferences for polls (start with simple tokanized model)
 5. Add qunit tests
 6. Many more...