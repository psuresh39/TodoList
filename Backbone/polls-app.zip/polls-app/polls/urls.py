from django.conf.urls.defaults import *


urlpatterns = patterns('polls.views',
    url(r'^$', 'detail', name='polls_detail'),
    url(r'^(?P<poll_id>\d+)/results/$', 'results', name='polls_results'),
)
